package ex06;

public class Comodo {
    private String comodo;

    public Comodo(String comodo) {
        this.comodo = comodo;

    }

    public String getComodo() {
        return comodo;
    }

    @Override
    public String toString() {
        return comodo;
    }

}
