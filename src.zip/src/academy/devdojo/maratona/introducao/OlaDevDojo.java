package academy.devdojo.maratona.introducao;

public class OlaDevDojo {
    public static void main(String[] args) {
        System.out.println("KA-ME-HA-ME-HA");
    }
}
