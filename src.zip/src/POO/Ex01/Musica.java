package POO.Ex01;

public class Musica {
}
