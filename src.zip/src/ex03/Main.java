package ex03;

public class Main {
    public static void main(String[] args) {
        Carros corola = new Carros("Toyota", "Corola", 200, "Flex");

        corola.printValores();
    }
}
